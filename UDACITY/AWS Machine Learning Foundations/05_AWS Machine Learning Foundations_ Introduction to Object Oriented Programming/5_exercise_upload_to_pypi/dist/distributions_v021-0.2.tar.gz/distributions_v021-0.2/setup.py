from setuptools import setup

setup(name='distributions_v021',
      version='0.2',
      description='Gaussian distributions',
      packages=['distributions_v021'],
      zip_safe=False)
